# v6.0.0 - December 14, 2022

## Highlights

- Support for Miui+
- Support for Mi Share
- Support for Miui AOD
- Support for Miui Weather
- Support for Miui Screenshot
- Support for MiLinkService (Mi Smart Hub, Cast)

## Other changes

- Design improvements, updates & fixes

---

# Donate

If you found this module helpful, please consider supporting the development, [**you can buy me a coffee**](https://paypal.me/geoorg). All support is appreciated.


Made with ❤️