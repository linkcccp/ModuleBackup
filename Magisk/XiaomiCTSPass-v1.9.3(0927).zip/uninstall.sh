#!/sbin/sh
MODDIR=${0%/*}
MODSDIR=$(dirname ${MODDIR%/*})/XiaomiCTSPass
rm -rf $MODSDIR
