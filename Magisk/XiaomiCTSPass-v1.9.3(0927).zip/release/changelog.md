
## v1.5.4-v1.5.5更新日志

1.修复小米11Pro机型代号读取错误的问题

2.更新以下机型的属性配置:

- 小米 MIX4  Android 12

- 小米12X  Android 12

- 小米10  Android 12

- 小米10至尊纪念版  Android 12

- 小米10 Pro  Android 12

- 小米10S  Android 12

- 小米10青春版  Android 12

- 小米平板5 Pro WiFi  Android 11

- 小米平板5 Pro  Android 11

- 小米平板5  Android 11

- Redmi K50  Android 12

- Redmi K50 Pro  Android 12

- Redmi K50 电竞版  Android 12

- Redmi K40  Android 12

- Redmi K40 游戏增强版  Android 12

- Redmi K30 4G  Android 12

- Redmi K30 5G  Android 12

- Redmi K30 Pro  Android 12

- Redmi K30 至尊纪念版  Android 12

- Redmi K30S 至尊纪念版  Android 12

- Redmi 10 5G  Android 12

- Redmi 10X 5G  Android 12

- Redmi 10X Pro  Android 12

- Redmi NOTE11 5G  Android 11  Android 12

- Redmi NOTE10 Pro  Android 11  Android 12


## v1.5.2-v1.5.3更新日志

1.更新以下机型的属性配置:

- Redmi NOTE10  Android 11

- Redmi NOTE10  Android 12

- 小米10至尊纪念版  Android 12

- 小米10S  Android 12

- 小米10青春版  Android 12

- 小米9 Pro  Android 11

- 小米平板5  Android 11

- 小米平板5 Pro WiFi  Android 11

- 小米平板5 Pro 5G  Android 11

- 小米8屏幕指纹版  Android 10

- Redmi NOTE11 5G  Android 11

- Redmi NOTE11 5G  Android 12

- Redmi NOTE10 Pro  Android 12

- Redmi NOTE9 Pro  Android 12

- 小米Civi  Android 12

- 小米12  Android 12

- 小米12X  Android 11

- 小米12X  Android 12

- 小米12 Pro  Android 12

- 小米CC9  Android 11

- 小米11  Android 12

- 小米11 青春版  Android 12

- Redmi K50  Android 12

- Redmi K50 Pro  Android 12

- Redmi K50 电竞版  Android 12

- Redmi K40 游戏增强版  Android 12

- Redmi K40  Android 12

- Redmi K40S  Android 12

- Redmi K30 5G  Android 12

- 小米11 Ultra  Android 12

- 小米Civi 1S  Android 12

- 小米 MIX Fold  Android 11

2.更新模块脚本


## v1.4.8-v1.5.1更新日志

1.更新以下机型的属性配置:

- 小米12  Android 12

- 小米10  Android 12

- 小米10S  Android 12

- 小米10 Pro  Android 12

- Redmi K30 Pro  Android 12

- Redmi K30 至尊纪念版  Android 11

- Redmi K30S 至尊纪念版  Android 12

- Redmi K40S  Android 12

- Redmi K50  Android 12

- Redmi K50 Pro  Android 12

- Redmi K50 电竞版  Android 12

- Redmi 10 5G  Android 12

- 小米平板5

2.更新模块脚本


## v1.4.7更新日志

1.更新以下机型的属性配置:

- 小米9 Pro  Android 11

- 小米9  Android 11

- 小米9 SE  Android 11

- 小米CC9 Pro  Android 11

- 小米CC9E  Android 11

- Redmi K20 Pro  Android 11

- Redmi K20  Android 11

- Redmi NOTE11 5G  Android 11

- Redmi NOTE8 Pro  Android 11

- Redmi NOTE8  Android 11

- Redmi NOTE7 Pro  Android 11

- Redmi NOTE7  Android 11


## v1.4.6更新日志

1.修复部分安卓12设备无法通过CTS检测的bug


## v1.4.5更新日志

1.解决在Recovery上刷模块时出现重复挂载和卸载的问题

2.修复在Recovery上刷模块时报错的问题


## v1.4.4更新日志

1.移除XiaomiCTSPass检测模块残留日志文件

2.更新以下机型的属性配置:

- 小米10青春版  Android 11

- 小米10S  Android 11

- 小米11 Pro  Android 11

- 小米11 Ultra  Android 11

- 小米11 青春版  Android 11

- Redmi K40  Android 11

- Redmi K40 Pro  Android 11

- Redmi K30 Ultra  Android 11

- Redmi NOTE9  Android 11

- Redmi NOTE10  Android 11

- Redmi NOTE11 4G  Android 11

- Redmi NOTE11 Pro  Android 11

- Redmi 10X 5G  Android 11

- Redmi 10X Pro 5G  Android 11

- 小米Civi  Android 11

- 小米平板5 Pro  Android 11

- 小米平板5 Pro WiFi  Android 11

- 小米平板5  Android 11

- Redmi K40 游戏增强版  Android 11
