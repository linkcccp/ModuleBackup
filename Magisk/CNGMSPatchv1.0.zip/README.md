# ModuleName
CnGMSPatch

## Introduction
Remove restriction of google services on China rom to make some features available such as nearby share and location history.

## Changelog

### v1.0
- Release
