rm -f /data/system/users/0/package-restrictions.xml
