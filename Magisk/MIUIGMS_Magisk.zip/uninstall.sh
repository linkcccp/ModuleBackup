rm -rf /data/user/0/com.google.android.gms/*
rm -f /data/system/users/0/package-restrictions.xml